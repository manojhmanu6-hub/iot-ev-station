#include "config.h"

// ---------------- WiFi Details ----------------
const char* WIFI_SSID = "Wokwi-GUEST";
const char* WIFI_PASS = "";

// ---------------- ThingsBoard Details ----------------
const char* MQTT_SERVER = "mqtt.thingsboard.cloud";
const int MQTT_PORT = 1883;

// ThingsBoard Device Access Token
const char* TB_TOKEN = "vft5bxLB4NbngGQplhXt";
const char* BAY_ID = "BAY3";
