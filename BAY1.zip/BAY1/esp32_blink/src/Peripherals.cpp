#include <Arduino.h>
#include "DHT.h"
#include "State.h"
#include "Peripherals.h"
#include "config.h"


DHT   dht(DHT_PIN , DHT_TYPE);

float mapFloat(long x, long inMin, long inMax, float outMin, float outMax){
    return (float)(x - inMin) * (outMax - outMin) / (float)(inMax - inMin) + outMin;
}
void sample_sensor(void)
{
    int raw_current = analogRead(CURRENT_PIN); // 0 to 4095 //0 to 32A
    int raw_voltage = analogRead(VOLTAGE_PIN); // 0 to 4095 // 0 to 250V
  // map 0 to 250 voltage
 voltage = mapFloat(raw_voltage, 0, 4095, 0, 250);
 if(bayStatus == "CHARGING")
 {
 // currebt is 0 to 32A
   current = mapFloat(raw_current, 0, 4095, 0, 32);
 }
 // read current and 5 values array 
 
 

 // caulate power 
  power = voltage * current;
  
    //to read temperature 
   float t = dht.readTemperature(DHT_PIN);
if(!(isnan(t))) temperature = t;
   
    
     


}

float recentAvgCurrent(void) {
  
    float sum=0;
    // read resent 5 current values
    for(int i=0;i<5;i++)
    {
        sum=sum+current;
    }
    return sum/5;
}






bool plugin_flag_once=1;
bool plugout_flag_once=1;

void plug_status(void)
{
   bool pluginreading =digitalRead(BTN_PLUGIN);
   // detect the sw is pressed
  if (pluginreading == LOW && plugin_flag_once == 1) 
  {
    //session time 
    sessionStartMs = millis();
  // plug in switch is pressed
      plugin_flag_once = 0;
       // change bay_status FREE to charging
       if(bayStatus == "FREE")
       {
           bayStatus = "CHARGING";
           Serial.println("Bay1 status is changed to CHARGING");
           digitalWrite(RELAY_PIN, HIGH); // turn on relay to start charging
       }
    }
       //update leds
if (pluginreading == HIGH ) // plug out switch is pressed
   {
       plugin_flag_once = 1;
       
   }
   // plug out switch is pressed
   bool plugoutreading =digitalRead(BTN_PLUGOUT);
   // detect the sw is pressed
  if (plugoutreading == LOW && plugout_flag_once == 1) // plug out switch is pressed
     { // plug out switch is pressed
      plugout_flag_once = 0;
       // change bay_status  charging to FREE
       if(bayStatus == "CHARGING")
       {
           bayStatus = "FREE";
           Serial.println("Bay status is changed to FREE");
       }
    }
       //update leds
if (plugoutreading == HIGH ) // plug out switch is pressed
   {
       plugout_flag_once = 1;
       
   }
   // change bay_status  charging to FREE
   //update leds





}
/*void update_leds(void)
{
    //if bay_status is "FREE" turn on green led 
    
        if(bayStatus == "FREE")
        {
            digitalWrite(LED_GREEN, HIGH);
            digitalWrite(LED_YELLOW, LOW);
          
        }
        else  //if bay_status is "CHARGING" turn on yellow led 

        {
            digitalWrite(LED_GREEN, LOW);
            digitalWrite(LED_YELLOW, HIGH);
        
        }
    }*/
   
