#ifndef PERIPHERALS_H
#define PERIPHERALS_H
#if __has_include(<DHT.h>)
#include <DHT.h>
#else
class DHT;
#endif

extern DHT dht;


void sample_sensor(void);
void plug_status(void);
void update_leds(void);
float recentAvgCurrent(void);
#endif