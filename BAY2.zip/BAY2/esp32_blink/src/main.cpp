#include <WiFi.h>
#include <Arduino.h>
#include <Arduino.h>
#include "State.h"
#include "config.h"
#include "Peripherals.h"
#include "Network.h"
#include "Telemetry.h"
#include "model.h"
#include "Edge_ai.h"
#include "optimization.h"
#include "rpc.h"
#include "attributes.h"

void setup()
{
//initialize serial monitor 
    Serial.begin(115200);
    dht.begin();  
    //config esp32 with real time 
    configTime(0, 0, "pool.ntp.org", "time.nist.gov");
    //config peripherals pin
   pinMode(BTN_PLUGIN, INPUT_PULLUP);
   pinMode(BTN_PLUGOUT, INPUT_PULLUP);
   pinMode(RELAY_PIN , OUTPUT);
   pinMode(LED_GREEN , OUTPUT);
   pinMode(LED_YELLOW , OUTPUT);
    pinMode(LED_RED , OUTPUT);

//connect to board to wifi
connectWiFi();

//conf mqtt server
    mqtt.setServer(MQTT_SERVER, MQTT_PORT);//mqtt server address of things and port number
    mqtt.setBufferSize(512);
    //set a callback function upon receiving data from cloud
    mqtt.setCallback(mqttCallback);

//connect board to cloud
connectMQTT();//token and device id

}

unsigned long now;
unsigned long last_print;

void loop()
{
    mqtt.loop();
    //push data every  5 sec
    now = millis();
    if((now - last_print) > 5000)
    {
        last_print = now;
         //read data from sensors current, voltage, power, temperature,power, bay status
        sample_sensor();
        //run edge ai to get the prediction 
            runEdgeAIInference();

        //decide the load based on the prediction and current load of the station
        if(manualOverrideActive==0)
        {
        runOptimization();
        }
             //publish data
            publishTelemetry();

    }

   plug_status();
   updateLeds();



}

